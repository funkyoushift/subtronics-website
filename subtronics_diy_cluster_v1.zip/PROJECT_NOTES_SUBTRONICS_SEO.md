
# Subtronics LLC SEO Project Notes (Updated)

## DIY Tutorial Cluster

Location:
/help/diy/

Purpose:
Create helpful repair tutorials that attract search traffic from people trying to fix their own computers.

Each page contains:
- Embedded YouTube tutorial
- Step-by-step instructions
- Tools required
- Troubleshooting tips
- Soft CTA linking to Subtronics services

## Current DIY Pages

how-to-install-a-gpu
how-to-replace-laptop-battery
how-to-apply-thermal-paste
how-to-upgrade-laptop-ram
how-to-clean-laptop-fan
pc-overheating-fix
computer-randomly-restarts
how-to-test-power-supply
how-to-update-bios
reinstall-windows-11

## SEO Strategy

These pages target long‑tail searches like:
- install gpu tutorial
- laptop battery replacement guide
- fix overheating pc
- reinstall windows 11

DIY visitors often convert into customers when repairs become difficult.
